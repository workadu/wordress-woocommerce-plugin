<?php
/**
 * Summary Removes direct access via index.
 *
 * @package Workadu
 * @version 1.0.0
 * @since  1.0.0
 */
